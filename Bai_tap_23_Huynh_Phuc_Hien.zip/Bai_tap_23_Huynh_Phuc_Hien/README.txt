BÀI TẬP 23 - ĐÈN KÉO QUÂN
Sinh viên: Huỳnh Phúc Hiền
MSSV: 231A290019

CẤU TRÚC THƯ MỤC
- index.html              Trang chủ, có link Bài 22 và Bài 23
- den-keo-quan.html       Trang đèn kéo quân 6 mặt
- style.css               CSS dùng chung
- den-keo-quan.css        CSS riêng cho đèn 3D
- den-keo-quan.js         JavaScript quay/dừng đèn
- images/hinh1.jpg ... hinh6.jpg   6 ảnh cá nhân

CÁCH THAY ẢNH
1. Chuẩn bị 6 ảnh cá nhân.
2. Đổi tên lần lượt thành hinh1.jpg, hinh2.jpg, hinh3.jpg, hinh4.jpg, hinh5.jpg, hinh6.jpg.
3. Đưa đủ 6 ảnh vào thư mục images, thay các ảnh mẫu/ảnh cũ nếu có.
4. Nếu ảnh có định dạng PNG, có thể đổi tên tham chiếu trong den-keo-quan.html từ .jpg sang .png cho đúng với tên tệp.

CẬP NHẬT LINK BÀI 22
Mở index.html và tìm dòng:
<a class="button secondary" href="#" ...
Khi có link Bài 22 được deploy riêng, thay href="#" bằng URL đầy đủ của Bài 22. Ví dụ:
<a class="button secondary" href="https://ten-bai-22.netlify.app/">Xem Bài tập 22</a>
Không dùng URL ví dụ này khi nộp; thay bằng URL thật của bạn.

DEPLOY NETLIFY
1. Đăng nhập GitHub bằng Safari trên iPad.
2. Tạo repository mới, ví dụ bai-tap-23-den-keo-quan.
3. Upload tất cả tệp/thư mục ở trong bộ source này lên thư mục gốc repository (không bắt buộc upload file README).
4. Vào https://app.netlify.com và đăng nhập.
5. Chọn Add new site / Import an existing project (tên nút có thể hơi khác).
6. Chọn GitHub, cấp quyền nếu được hỏi, rồi chọn repository.
7. Build command: để trống.
8. Publish directory: . (dấu chấm) hoặc để trống nếu giao diện tự dùng thư mục gốc.
9. Chọn Deploy site.
10. Mở link .netlify.app do Netlify cấp, kiểm tra index.html và den-keo-quan.html.

CHỤP ẢNH NỘP BÀI TRÊN IPAD
1. Mở link Netlify, chụp màn hình trang chủ có tên và MSSV.
2. Mở trang đèn kéo quân, chụp màn hình khi đèn đang quay.
3. Nếu cần chứng minh chức năng dừng, chạm vào một mặt trên iPad và chụp màn hình trạng thái "Đèn đã dừng".
4. Nộp link Netlify, các ảnh chụp màn hình và source code ZIP.

LƯU Ý
- Bài hiện đã có vị trí chờ cho link Bài 22 vì chưa có URL.
- Không thể tạo link Netlify thật nếu chưa upload/deploy bằng tài khoản của bạn.
- Nên kiểm tra link sau khi deploy; bảo đảm 6 ảnh đã được upload và không còn ảnh bị lỗi.
